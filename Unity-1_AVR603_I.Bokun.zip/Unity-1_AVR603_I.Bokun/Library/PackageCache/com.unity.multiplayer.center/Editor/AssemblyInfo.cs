using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Unity.Multiplayer.Center.Editor.Tests")]
[assembly:InternalsVisibleTo("Unity.Multiplayer.Center.Integrations")]
[assembly:InternalsVisibleTo("Unity.Multiplayer.Center.GettingStartedTab.Tests")]
